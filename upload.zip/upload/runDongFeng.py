import streamlit as st 
import numpy as np 

import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.model_selection import train_test_split

from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from PIL import Image

import numpy as np
import matplotlib.pyplot as plt 
import scipy.io as sio
import torch 
import pandas as pd 
import os

from sklearn.metrics import accuracy_score
from mpl_toolkits.axes_grid1 import make_axes_locatable



from utils import colNorm, vis1Dfeature, makeLabel2, time2rms
from utils import dataset_split, train_model#,animateData



# st.title('东风设备有限公司机床远程监控演示平台')
st.write("""
## **东风机床状态监测与故障诊断模型训练平台(演示)**
- 设备单位：东风设备制造有限公司
- 协作单位：西门子(中国)有限公司
- 研发单位：华中科技大学
- 演示时间：2020年12月

""")


demo = Image.open('demo.png')
st.image(demo, caption='图 1 设备现场与加速度传感数据采集演示', use_column_width=True)



c1 = sio.loadmat('Data/condition1.mat')['data']
c2 = sio.loadmat('Data/condition2.mat')['data']
c3 = sio.loadmat('Data/condition3.mat')['data']
c4 = sio.loadmat('Data/condition4.mat')['data']
c5 = sio.loadmat('Data/condition5.mat')['data']
c6 = sio.loadmat('Data/condition6.mat')['data']

sample = np.array([len(i) for i in [c1, c2, c3, c4, c5, c6]]).reshape(1,-1)
sampleLen = pd.DataFrame(sample,columns=['C1','C2','C4','C4','C5','C6'],index=['#'])

st.write("## 1.数据分析")
st.write("### 1.1 六种设备状态(C1-C6)与样本数量(#)")
st.write(sampleLen)


st.write("### 1.2 波形均值图")
fig, axes = plt.subplots(6,figsize=(10,10))
axes[0].plot(np.mean(c1,axis=0))
axes[1].plot(np.mean(c2,axis=0))
axes[2].plot(np.mean(c3,axis=0))
axes[3].plot(np.mean(c4,axis=0))
axes[4].plot(np.mean(c5,axis=0))
axes[5].plot(np.mean(c6,axis=0))
axes[0].set_title('C1')
axes[1].set_title('C2')
axes[2].set_title('C3')
axes[3].set_title('C4')
axes[4].set_title('C5')
axes[5].set_title('C6')
plt.tight_layout()
st.pyplot(fig)


st.write("### 1.3 时序分布图")
fig, axes = plt.subplots(1,6,figsize=(8,3.5))
axes[0].matshow(c1,aspect='auto',cmap='jet')
axes[1].matshow(c2,aspect='auto',cmap='jet')
axes[2].matshow(c3,aspect='auto',cmap='jet')
axes[3].matshow(c4,aspect='auto',cmap='jet')
axes[4].matshow(c5,aspect='auto',cmap='jet')
axes[5].matshow(c6,aspect='auto',cmap='jet')
axes[0].set_xticks([])
axes[1].set_xticks([])
axes[2].set_xticks([])
axes[3].set_xticks([])
axes[4].set_xticks([])
axes[5].set_xticks([])
axes[0].set_title('C1')
axes[1].set_title('C2')
axes[2].set_title('C3')
axes[3].set_title('C4')
axes[4].set_title('C5')
axes[5].set_title('C6')
plt.tight_layout()
st.pyplot(fig)



st.write("""
## 2. 数据预处理
### 2.1 数据筛选
- C1, C2, C3 时域分布相似，初选C1
- C4, C6 时域分布相似，初选C4, C6
- C2, C3, C5 建议现场重新考虑传感器的部署及采集方式

""")


st.write("""
### 2.2 训练测试数据集
- 选取 C1, C4, C5 用于本次训练、测试 
- 训练集与测试及按照7:3进行划分
- 特征变换选取FFT变换后的切片算术均方值RMS作为特征


$$RMS = \sqrt{\\frac{1}{n}\sum_{i=1}x^2_{Li}}$$
""")

# Label preparation
allData=False
if allData == True:
    defineCategories = [0,0,0,1,2,1]
    countDatumLength = [157,157,132,157,157,157]
else:
    defineCategories = [0,1,2]
    countDatumLength = [157,157,157]


dataSelect = colNorm(np.concatenate([c1,c4,c5]))
dataFea = time2rms(dataSelect, nfft=2**14,fw=32,dataset='Dongfeng',source='All',fmt = 'raw')
label1, label2 = makeLabel2(categories=defineCategories,catesample=countDatumLength,vis=False)


st.write("""
### 2.3 特征及标签可视化

""")

fig, axes = plt.subplots(1,2,figsize=(10,4))
divider = make_axes_locatable(axes[0])
cax = divider.append_axes('right', size='5%', pad=0.05)
im = axes[0].matshow(dataFea,aspect='auto',cmap='jet')
ylines = [157,157]
for ydx, y in enumerate(ylines):
        axes[0].axhline(y=np.cumsum(ylines)[ydx],c='r',lw=2)
fig.colorbar(im, cax=cax, orientation='vertical')
axes[1].plot(label1)
axes[1].minorticks_off()
plt.tight_layout()
st.pyplot(fig)


st.write("""
## 3 模型训练与测试
""")


st.write("""
### 3.1 训练集测试集划分
""")
R = st.sidebar.slider('设置测试集百分比', 0.3, 1.0)



X_train, X_test, y_train, y_test = dataset_split(dataFea,label1,ttr=R,scale='raw')

st.write(f'训练集: {X_train.shape}')
st.write(f'测试集: {X_test.shape}')
st.write(f'测试集百分比: {R}')


#%%



classifier_name = st.sidebar.selectbox(
    '选择分类器',
    ('SVM', 'KNN', 'Random Forest')
)

def add_parameter_ui(clf_name):
    params = dict()
    if clf_name == 'SVM':
        C = st.sidebar.slider('C', 10.0, 100.0)
        params['C'] = C
    elif clf_name == 'KNN':
        K = st.sidebar.slider('K', 1, 15)
        params['K'] = K
    else:
        max_depth = st.sidebar.slider('max_depth', 2, 15)
        params['max_depth'] = max_depth
        n_estimators = st.sidebar.slider('n_estimators', 1, 100)
        params['n_estimators'] = n_estimators
    return params

params = add_parameter_ui(classifier_name)

def get_classifier(clf_name, params):
    clf = None
    if clf_name == 'SVM':
        clf = SVC(kernel='rbf', C=params['C'])
    elif clf_name == 'KNN':
        clf = KNeighborsClassifier(n_neighbors=params['K'])
    else:
        clf = clf = RandomForestClassifier(n_estimators=params['n_estimators'], 
            max_depth=params['max_depth'], random_state=1234)
    return clf

clf = get_classifier(classifier_name, params)
#### CLASSIFICATION ####

# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1234)

clf.fit(X_train, y_train)


st.write("""
### 3.2 训练测试结果
""")
st.write(f'Classifier = {classifier_name}')


st.write("""
- 蓝色实心：C1
- 绿色实心：C4
- 青色实心：C5
- 蓝色外边：正确预测
- 红色外边：错误预测
""")


#### PLOT DATASET ####
# Project the data onto the 2 primary principal components
y_pred = clf.predict(X_test)
acc = accuracy_score(y_test, y_pred)

st.write(f'Test accuracy =', acc)

C = []

for idx, item in enumerate(y_pred):
    if item == y_test[idx]:
        C.append('b') 
    else:
        C.append('r')

from sklearn.decomposition import PCA
pca = PCA(2)
X_projected = pca.fit_transform(X_test)

x1 = X_projected[:, 0]
x2 = X_projected[:, 1]

fig = plt.figure()
plt.scatter(x1, x2, c=y_test, alpha=1, cmap='jet',edgecolor=(C))

plt.xlabel('Principal component 1')
plt.ylabel('Principal component 2')
plt.title('Diagnosis accuracy: {:.2%}'.format(acc))
plt.colorbar()
st.pyplot(fig)

#%%


