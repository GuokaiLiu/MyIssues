#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   utils.py
@Time    :   2020/12/13 10:53:49
@Author  :   GuokLiu
@Contact :   liuguokai@hust.edu.cn
@Institution   :  Huazhong Univ. of Sci. and Tech.
@Desc    :   None
'''

# Import essential1 libraries

def colNorm(a):
    import numpy as np
    b = np.max(a,axis=0)
    c = np.mean(a,axis=0)
    d = (a-c)/(b-c)
    return d


def vis1Dfeature(data,title='vis1Dfeature',yloc=[]):
    import matplotlib.pyplot as plt
    import numpy as np
    plt.figure(figsize=(10,7),)
    plt.matshow(data,cmap='jet',fignum=1,aspect='auto')
    for ydx, y in enumerate(yloc):
        plt.axhline(y=np.cumsum(yloc)[ydx]-1,c='r',lw=3)
    plt.colorbar()
    plt.title(title)
    # plt.savefig('demo.png',bbox_inches='tight')
    plt.show()



def makeLabel2(categories=[0,1,2,3,4,5],catesample=[157,157,132,157,157,157],vis=False):
    import matplotlib.pyplot as plt
    import numpy as np
    from mpl_toolkits.axes_grid1 import make_axes_locatable

    labels = []
    for cdx, ctg in enumerate(categories):
        labels = labels + (np.ones(catesample[cdx])*ctg).tolist()
    labelLabel = np.array(labels)
    oht = np.eye(len(set(categories)))
    labelOnehot = oht[labelLabel.astype('int')]

    if vis==True:
        # 0 Setting
        fig, axes = plt.subplots(nrows=1, ncols=2,figsize=(7,3))
        divider = make_axes_locatable(axes[1])
        cax = divider.append_axes('right', size='5%', pad=0.05)
        # 1 Label encoding
        axes[0].plot(labelLabel)
        axes[0].set_title('Label encoding')
        # 2 Onehot encoding
        im = axes[1].matshow(labelOnehot,cmap= 'jet',aspect='auto')
        axes[1].xaxis.tick_bottom()
        axes[1].set_title('Onehot encoding')
        fig.colorbar(im, cax=cax, orientation='vertical')
        # plt.tight_layout()
    plt.show()
    return labelLabel, labelOnehot

def time2rms(data, nfft=2**14,fw=32,dataset='CWRU',source='A',fmt = 'norm'):
    import scipy.signal as signal
    import scipy.io as sio
    import numpy as np
    import os
    import matplotlib.pyplot as plt
    
    # check
    file_name = 'Features/{}_{}.mat'.format(dataset,fmt)
    if os.path.isfile(file_name):
        return sio.loadmat(file_name)['source']
    if not os.path.exists('Features/{}'.format(dataset)):
        os.makedirs('Features/{}'.format(dataset))
    # feature extraction
    han = data*signal.hann(data.shape[1], sym=0)
    fft = np.fft.fft(han, nfft, axis=1)
    amp = np.abs(fft[:, 0:int(nfft/2)])*2/nfft
    sli = amp.reshape(amp.shape[0], fw*fw, -1)
    # rms = np.array([np.sqrt(np.sum(s**2,axis=1)/s.shape[1]) for s in sli])
    rms = np.array([np.sqrt(np.sum(s, axis=1)/s.shape[1]) for s in sli])
    # normalize: rms - norm - cm.jet - rbg 
    norm = plt.Normalize()
    if fmt == 'norm':   # One channel
        rms = np.array(norm(rms)) # [0,1]
    elif fmt == 'rgba': # Three channels
        rms = cm.jet(norm(rms), bytes=True)[:,:,:3] # RGBA - RGB [0, 255]
    elif fmt == 'uint8':
        rms = (np.array(norm(rms))*255).astype('uint8')
    elif fmt == 'raw':
        rms = rms
    # save
    # file_dict = {'source':rms,'target':lab}
    # sio.savemat(file_name, mdict=file_dict) # RGB channels
    return rms


def dataset_split(dataset,label,ttr=0.3,scale='Std'):
    from sklearn.model_selection import train_test_split
    from sklearn import metrics, preprocessing
    from collections import Counter
    
    Xtr, Xte, Ytr, Yte = train_test_split(dataset,label,test_size=ttr,random_state=10) #
    print('Training samples: ', Counter(Ytr.ravel()))
    print('Tesing samples: ',Counter(Yte.ravel()))
    if scale == 'std':
        scaler = preprocessing.StandardScaler().fit(Xtr)
        Xtr = scaler.transform(Xtr)   
        Xte = scaler.transform(Xte)
    elif scale == 'min_max':
        scaler = preprocessing.MinMaxScaler().fit(Xtr)
        Xtr = scaler.transform(Xtr)   
        Xte = scaler.transform(Xte)
    else:
        Xtr = Xtr
        Xte = Xte
    return Xtr, Xte, Ytr, Yte  

def train_model(model, x_train, x_test, y_train, y_test,model_name):
    from sklearn import metrics
    model.fit(x_train, y_train)  
    y_pred = model.predict(x_test)   
    print("{:<30}{:>12.3%}".format(model_name, metrics.accuracy_score(y_test, y_pred))) 



def animateData(model, data, labels,saveName='animatedData.gif'):
    import matplotlib.pyplot as plt 
    from celluloid import Camera
    import numpy as np

    fig, ax1 = plt.subplots(1)
    camera = Camera(fig)
    t = np.linspace(0, 0.1, 1024, endpoint=False)
    # data = sio.loadmat('Data/condition1.mat')['data'].ravel()  
    for i in range(10):#(len(label)):
        predLabel = model.predict(data[i,:].reshape(1,-1))[0]
        trueLabel = labels[i]
        # print(predLabel,trueLabel)
        label = 'Pred-{},True-{}'.format(int(predLabel),int(trueLabel))
        print(label)
        l = plt.plot(t, data[i,:], color='blue')
        plt.legend(l,[f'line {i}'])
        camera.snap()
        
    animation = camera.animate()  
    animation.save(saveName, writer = 'imagemagick')


# animateData(model,Xtr,Ytr)